# Sticky Notes Application - Design Diagrams

## 1. Use Case Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Sticky Notes System                       │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│                    ┌──────────────┐                          │
│                    │    Actor     │                          │
│                    │     User     │                          │
│                    └──────┬───────┘                          │
│                           │                                   │
│        ┌──────────────────┼──────────────────┐              │
│        │                  │                  │              │
│        ▼                  ▼                  ▼              │
│   ┌─────────┐      ┌─────────┐      ┌─────────┐           │
│   │ View    │      │ Create  │      │ Update  │           │
│   │  Notes  │      │  Notes  │      │  Notes  │           │
│   └─────────┘      └─────────┘      └─────────┘           │
│        │                  │                  │              │
│        └──────────────────┼──────────────────┘              │
│                           │                                   │
│                           ▼                                   │
│                    ┌─────────────┐                          │
│                    │ Delete Note │                          │
│                    └─────────────┘                          │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 2. Sequence Diagram

```
User          Browser         Django              Database
 │               │              │                    │
 │─ Create ────→ │              │                    │
 │   Note        │              │                    │
 │               │─ POST ──────→ │                    │
 │               │               │─ Save ───────────→│
 │               │               │                   │
 │               │ ←─ Response ──│                    │
 │ ←─ Redirect ──│               │                    │
 │               │               │                    │
 │─ View ───────→│               │                    │
 │   Notes       │               │                    │
 │               │─ GET ────────→│                    │
 │               │               │─ Query ──────────→│
 │               │               │ ←─ Data ─────────│
 │               │ ←─ HTML ──────│                    │
 │ ←─ Display ───│               │                    │
 │               │               │                    │
 │─ Delete ─────→│               │                    │
 │   Note        │               │                    │
 │               │─ DELETE ─────→│                    │
 │               │               │─ Delete ─────────→│
 │               │               │ ←─ Confirm ──────│
 │               │ ←─ Response ──│                    │
 │ ←─ Redirect ──│               │                    │
```

## 3. Class Diagram

```
┌───────────────────────────────┐
│           Author              │
├───────────────────────────────┤
│ - id: int                     │
│ - name: str                   │
├───────────────────────────────┤
│ + __str__() → str             │
└───────────────────────────────┘
           ▲
           │ 1
           │
           │ *
           │
┌───────────────────────────────┐
│           Post                │
├───────────────────────────────┤
│ - id: int                     │
│ - title: str                  │
│ - content: str                │
│ - created_at: datetime        │
│ - author: ForeignKey          │
├───────────────────────────────┤
│ + __str__() → str             │
│ + save()                      │
│ + delete()                    │
└───────────────────────────────┘
           ▲
           │
           │ uses
           │
┌───────────────────────────────┐
│        PostForm               │
├───────────────────────────────┤
│ - title: CharField            │
│ - content: TextField          │
│ - author: SelectField         │
├───────────────────────────────┤
│ + is_valid() → bool           │
│ + save() → Post               │
│ + clean()                     │
└───────────────────────────────┘
           ▲
           │
           │ processes
           │
┌───────────────────────────────┐
│       Views                   │
├───────────────────────────────┤
│ + post_list()                 │
│ + post_detail()               │
│ + post_create()               │
│ + post_update()               │
│ + post_delete()               │
└───────────────────────────────┘
```

## Design Rationale

### Model Design
- **Post** and **Author** models follow a one-to-many relationship
- Each post belongs to one author, but an author can have multiple posts
- ForeignKey with CASCADE delete ensures data consistency

### View Design
- Function-based views handle HTTP requests
- CRUD operations mapped to separate view functions
- Views use Django shortcuts (render, redirect, get_object_or_404)

### Form Design
- ModelForm automatically generates form from Post model
- Form handles validation and data cleaning
- Reduces code duplication and improves maintainability

### URL Routing
- RESTful URL patterns for intuitive navigation
- Named URLs allow template reverse lookups
- Clear separation between list, detail, create, update, delete operations
