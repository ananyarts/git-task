from django.test import TestCase
from django.urls import reverse
from .models import StickyNote


class StickyNoteModelTest(TestCase):
    def setUp(self):
        StickyNote.objects.create(
            title='Test Note',
            content='This is a test note.'
        )

    def test_sticky_note_has_title(self):
        note = StickyNote.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')

    def test_sticky_note_has_content(self):
        note = StickyNote.objects.get(id=1)
        self.assertEqual(note.content, 'This is a test note.')

    def test_sticky_note_string_representation(self):
        note = StickyNote.objects.get(id=1)
        self.assertEqual(str(note), 'Test Note')

    def test_sticky_note_title_max_length(self):
        note = StickyNote.objects.get(id=1)
        max_length = note._meta.get_field('title').max_length
        self.assertEqual(max_length, 255)


class StickyNoteFormTest(TestCase):
    def test_form_with_valid_data(self):
        from .forms import StickyNoteForm
        form = StickyNoteForm(data={
            'title': 'Test Title',
            'content': 'Test content'
        })
        self.assertTrue(form.is_valid())

    def test_form_with_missing_title(self):
        from .forms import StickyNoteForm
        form = StickyNoteForm(data={
            'title': '',
            'content': 'Test content'
        })
        self.assertFalse(form.is_valid())

    def test_form_with_missing_content(self):
        from .forms import StickyNoteForm
        form = StickyNoteForm(data={
            'title': 'Test Title',
            'content': ''
        })
        self.assertFalse(form.is_valid())


class StickyNoteViewTest(TestCase):
    def setUp(self):
        StickyNote.objects.create(
            title='Test Note',
            content='This is a test note.'
        )

    def test_sticky_note_list_view(self):
        response = self.client.get(reverse('post_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')
        self.assertContains(response, 'This is a test note.')

    def test_sticky_note_detail_view(self):
        note = StickyNote.objects.get(id=1)
        response = self.client.get(reverse('post_detail', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')

    def test_sticky_note_create_view(self):
        response = self.client.get(reverse('post_create'))
        self.assertEqual(response.status_code, 200)

    def test_sticky_note_create_post(self):
        response = self.client.post(reverse('post_create'), {
            'title': 'New Note',
            'content': 'New content'
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(StickyNote.objects.count(), 2)

    def test_sticky_note_update_view(self):
        note = StickyNote.objects.get(id=1)
        response = self.client.get(reverse('post_update', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)

    def test_sticky_note_update_post(self):
        note = StickyNote.objects.get(id=1)
        response = self.client.post(reverse('post_update', args=[str(note.id)]), {
            'title': 'Updated Note',
            'content': 'Updated content'
        })
        self.assertEqual(response.status_code, 302)
        note.refresh_from_db()
        self.assertEqual(note.title, 'Updated Note')

    def test_sticky_note_delete_view(self):
        note = StickyNote.objects.get(id=1)
        response = self.client.get(reverse('post_delete', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)

    def test_sticky_note_delete_post(self):
        note = StickyNote.objects.get(id=1)
        response = self.client.post(reverse('post_delete', args=[str(note.id)]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(StickyNote.objects.count(), 0)


class StickyNoteIntegrationTest(TestCase):
    def test_create_and_retrieve_note(self):
        StickyNote.objects.create(
            title='Integration Test',
            content='Testing CRUD flow'
        )
        note = StickyNote.objects.get(title='Integration Test')
        self.assertEqual(note.content, 'Testing CRUD flow')

    def test_list_view_displays_multiple_notes(self):
        StickyNote.objects.create(title='Note 1', content='Content 1')
        StickyNote.objects.create(title='Note 2', content='Content 2')
        response = self.client.get(reverse('post_list'))
        self.assertContains(response, 'Note 1')
        self.assertContains(response, 'Note 2')
