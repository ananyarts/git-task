from django.shortcuts import render, get_object_or_404, redirect
from .models import StickyNote
from .forms import StickyNoteForm


def post_list(request):
    notes = StickyNote.objects.all()
    context = {'posts': notes, 'page_title': 'Sticky Notes'}
    return render(request, 'posts/post_list.html', context)


def post_detail(request, pk):
    note = get_object_or_404(StickyNote, pk=pk)
    return render(request, 'posts/post_detail.html', {'post': note})


def post_create(request):
    if request.method == 'POST':
        form = StickyNoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('post_list')
    else:
        form = StickyNoteForm()
    return render(request, 'posts/post_form.html', {'form': form, 'page_title': 'New Note'})


def post_update(request, pk):
    note = get_object_or_404(StickyNote, pk=pk)
    if request.method == 'POST':
        form = StickyNoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect('post_detail', pk=pk)
    else:
        form = StickyNoteForm(instance=note)
    return render(request, 'posts/post_form.html', {'form': form, 'page_title': 'Edit Note', 'post': note})


def post_delete(request, pk):
    note = get_object_or_404(StickyNote, pk=pk)
    if request.method == 'POST':
        note.delete()
        return redirect('post_list')
    return render(request, 'posts/post_confirm_delete.html', {'post': note})
